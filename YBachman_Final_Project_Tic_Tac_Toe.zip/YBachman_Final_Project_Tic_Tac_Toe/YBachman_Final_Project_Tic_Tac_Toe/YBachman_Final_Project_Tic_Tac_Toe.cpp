/*
Final Project Fall Semester 2014
C++ I
Yulia Bachman
Tic-Tac-Toe (No More)
*/

#include <iostream>  //For cout, cin, etc.
#include <sstream>   //For stringstream: type of cout which can be passed into functions
#include <string>    //For strings
#include <ctime>     //For random function ("against computer" mode only)
#include <fstream>   //For files for users (userInfo)
#include <vector>	 //For vector usage (better than an array due to no set-in-stone size)
#include <fstream>	 //For the file which stores user account information

using namespace std;

//Structure for User Accounts
struct UserInfo
{
    string name;
    string password;
    string email;
    int wins;
    int losses;
    int draws;
};

//Used for readability of the code; Allows typing of "userList" instead of "vector<userInfo>"
typedef vector<UserInfo> UserList;

//GLOBAL VARIABLES

//Flag player
bool player1;
//Array size
int BOARD_SIZE = 0;
//Modify Board Size
int modifier = 0;
//Increments up to number of spaces, which equals tie
int moveCount;
//Flag for winner
bool win;
//Create Board
char** board;
//If mood is invalid
bool invalidMove;
//Draw
bool draw;
//User input
int user_input;
//Flag for Against computer option
bool cpu;
//Stores number of accounts in file (from first line in the file itself)
int numOfAccounts;

//For login; users for the game
UserInfo* player1User;
UserInfo* player2User;
UserInfo* activeUser;
UserInfo guest1;
UserInfo guest2;

//Function prototypes
int checkNum (string prompt);
void newGame(bool com); //Check for computer foe
void swapTurn();
void display();
void update();
void input();
bool winner();
bool other ();
void end();
int computerMove();

//User Function Prototypes
void readUsersFromFile( UserInfo&, fstream&);
void writeUsersToFile( UserInfo&, fstream&);
UserInfo* findUser( UserList&, string);
void display( const UserInfo&);



int main()
{ 
	//Naming Guest
	guest1.name = "Player1";
    guest2.name = "Player2";

	//Creates an empty list using userInfo structure
    UserList list;
    
    //Create file object, opens file
    fstream file( "users.txt", ios::in );

    //Extracts number of accounts in file (from line 1) and uses it as a sentinel vaue to detect end of file
    file >> numOfAccounts;
    file.ignore();

	//Read the number store in numOf Accounts and read all the names of current accounts
	for (int count = 0; count < numOfAccounts; count++)
	{
		UserInfo user;
		readUsersFromFile(user, file );
		
		//Stores user into the list
		list.push_back(user);
	}

	//Close file
	file.close();

	//For menu options
	int userChoice = 0;
	int userChoiceSize;
	string loginName;
    string password;

	//Display Title
	string title[3] = {"+-+-+-+-+-+-+-+-+-+-+-+\n",
						"|T|i|c|-|T|a|c|-|T|o|e|\n",
						"+-+-+-+-+-+-+-+-+-+-+-+\n"};

	//While userChoice isn't "Quit"
	while (userChoice != 4)
	{
		//Display title
		for (int i = 0; i < 3; i++)
		{
			cout << title[i];	
		}

		cout << " \n" << endl;

		//Display main menu (login)
		cout << "Please chose an option by the number.\n";
		cout << "-------------------------------------\n\n";
		cout << "1. Login\n";
		cout << "2. Create an Account\n";
		cout << "3. Play as a Guest\n";
		cout << "4. Quit\n\n";

		//get user choice
		cin >> userChoice;

			//Validate user choice
			while (userChoice < 1 || userChoice > 4)
			{
				//Display title
				for (int i = 0; i < 3; i++)
				{
					cout << title[i];	
				}

				cout << " \n" << endl;

				cout << "\nYou have not selected a valid option from the menu. Please select 1 - 4\n";

				//Display main menu again(login)
				cout << "Please chose an option by the number.\n";
				cout << "-------------------------------------\n\n";
				cout << "1. Login\n";
				cout << "2. Create an Account\n";
				cout << "3. Play as a Guest\n";
				cout << "4. Quit\n\n";

				//get user choice
				cin >> userChoice;
			}

		//Menu Navigation (1 player)
		switch (userChoice)
		{
		//Prompt for username
		case 1:
			{
				bool playasGuest = false;
				UserInfo* user;

				// OUTER LOOP until user enters '-1' while typing user name
				while(true)
				{
					// initial user name prompt
					cout << "\nPlease enter your username\n\n";
					cin >> loginName;
					cin.ignore();

					//Check for user existing in file
					user = findUser(list, loginName);
                
					// loop until a user name is found or if user enters '-1'
					while(user == 0 && loginName.compare("-1") != 0)
					{
						//If user not found, re prompt user
						cout << "\nUsername not found. Please try again; or type -1 to exit.\n\n";
						cin >> loginName;
						user = findUser(list, loginName);
					}

					// if user entered -1 for user name then play as guest
					if(loginName.compare("-1") == 0)
					{
						cout << "\nYou will now be logged in as a guest.\n";
						player1User = &guest1;

						// set guest flag to true
						playasGuest = true;

						// leave outer loop
						break;
					}

					// initial prompt for password
					cout << "\nPlease enter your password\n\n";
					cin >> password;

					// loop until correct password is entered or until user enters '-1'
					while(password.compare(user->password) != 0 && password.compare("-1") != 0)
					{
						//If wrong password, reprompt user
						cout << "\nIncorrect password. Please try again; or type -1 to try a new username.\n\n";
						cin >> password;
						cin.ignore();
					}

					// if user enters a correct password then login is complete. exit outer loop
					if (password.compare(user->password) == 0)
						break;

					// else loop to beginning to enter a new username

				}// END OF OUTER LOOP

				// if guest flag is true then break out of switch statement to start game as guest
				if (playasGuest)
					break;
			    
				player1User = user;
				//New line
				cout << " \n";

				//Display user information
				display(*user);

				system("pause");
         
				break;
			}
		case 2:
			{
				//Variable for new user object
				string newUser;
				UserInfo* user = new UserInfo;

				//Prompt
				cout << "\nEnter your new username or press -1 to cancel:\n";
				cin >> newUser;

				//Ignore blank line
				cin.ignore();

				//Check for username existing in file already
				UserInfo* test = findUser(list, newUser);
                
				// loop until a user name is found or if user enters '-1'
				while(test != 0 && newUser.compare("-1") != 0)
				{
					//If user not found, re prompt user
					cout << "\nUsername already in use. Please try again; or type -1 to exit.\n\n";
					cin >> newUser;
					test = findUser(list, loginName);
				}
			
				//Input username
				if (newUser.compare("-1") == 0)
				{
					cout << "\nYou will now be logged in as a guest.\n";
					//-1 means cancel
					player1User = &guest1;
					break;
				}
				user->name = newUser;

				//Input password
				cout << "\nEnter you desired password.\n";
				cin >> user -> password;

				//Ignore blank line
				cin.ignore();

				//Input e-mail
				cout << "\nEnter you e-mail (including @).\n";
				cin >> user -> email;

				//Ignore blank line
				cin.ignore();

				//Setting the wins, draws, and lossed to 0
				user -> wins = user -> losses = user -> draws = 0;

				//New line
				cout << " \n";

				//Display user information
				display(*user);

				system("pause");

				//adding new user to the main list
				list.push_back(*user);

				//assigning our new user to player 1
				player1User = &list.back();
			}
			break;
		case 3: 
			player1User = &guest1;	//Assigns guest to player 1
			break;
		case 4:
			cout << "\nThanks for playing! Now exiting the program...\n\n";
			//Quits program
			exit(0);
			break;
		}

	//Reset userChoice
	userChoice = 0;

	//While loop to keep playing until quit is entered
	while (userChoice != 3)
	{
		//Display title
		for (int i = 0; i < 3; i++)
		{
			cout << title[i];	
		}

		cout << " \n" << endl;

		//Display menu
		cout << "\nPlease chose an option by the number.\n";
		cout << "-------------------------------------\n\n";
		cout << "1. Against computer\n";
		cout << "2. Against another player\n";
		cout << "3. Quit\n\n";

		//get user choice
		cin >> userChoice;

		while (userChoice < 1 || userChoice > 3)
			{
				//Error trap to check for 1, 2, or 3 to be entered.
				cout << "\n\nYou did not enter 1, 2, or 3. Please chose a valid option.\n\n";
				cin >> userChoice;
			}

		if (userChoice == 1)
			{            
				//Display Title
				for (int i = 0; i < 3; i++)
				{
					cout << title[i];	
				}

				cout << " \n" << endl;

				//Display question for BOARD_SIZE
				cout << "\nPlease chose a board size.\n";
				cout << "-----------------------------\n\n";
				cout << "3. 3 x 3 board\n";
				cout << "4. 4 x 4 board\n";
				cout << "5. 5 x 5 board\n";
				cin >> userChoiceSize;  //Get user's size choice

				while (userChoiceSize < 3 || userChoiceSize > 5)
				{
					//Error trap to check for 3, 4, or 5 to be entered.
					cout << "\n\nYou did not enter 3, 4, or 5. Please chose a valid option.\n\n";
					cin >> userChoiceSize;
				}

				//Set the modifier for Key Pad
				if (userChoiceSize == 3)
					modifier = 7;
				else if (userChoiceSize == 4)
					modifier = 13;
				else
					modifier = 21;

				//Set Board Size to choice
				BOARD_SIZE = userChoiceSize;

                // set player 2 as guest
                player2User = &guest2;

			    //Start new game against computer
			    newGame(true);
			}

		else if (userChoice == 2)
		{
			//Display Title                        
			for (int i = 0; i < 3; i++)
			{
				cout << title[i];	
			}

			cout << " \n" << endl;

			//Display main menu (login)
			cout << "\nPlayer 2, chose an option.\n";
			cout << "-------------------------------------\n\n";
			cout << "1. Login\n";
			cout << "2. Create an Account\n";
			cout << "3. Play as a Guest\n\n";

			//get user choice
			cin >> userChoice;

				//Validate user choice
				while (userChoice < 1 || userChoice > 3)
				{
					//Display Title                
					for (int i = 0; i < 3; i++)
					{
						cout << title[i];	
					}

					cout << " \n" << endl;

					cout << "\nYou have not selected a valid option from the menu. Please select 1 - 4\n";

					//Display main menu again(login)
					cout << "\nPlayer 2, chose an option.\n";
					cout << "-------------------------------------\n\n";
					cout << "1. Login\n";
					cout << "2. Create an Account\n";
					cout << "3. Play as a Guest\n\n";

					//get user choice
					cin >> userChoice;
				}

			//Menu Navigation (2 player)
			switch (userChoice)
			{
			//Prompt for username (player 2)
			case 1:
				{
					bool done = false;
                    bool playasGuest = false;
                    UserInfo* user;

                    // OUTER LOOP until user enters '-1' while typing user name
                    while(true)
                    {
			            // initial user name prompt
                        cout << "\nPlease enter your username\n\n";
			            cin >> loginName;
                        cin.ignore();

                        //Check for user existing in file
			            user = findUser(list, loginName);
                
                        // loop until a user name is found or if user enters '-1'
                        while((user == 0 || user == player1User) && loginName.compare("-1") != 0)
			            {
				            // if Second player is the same as first player
                            if (user == player1User)
                            {
                                cout << "\nPlayer 2 cannot be the same user as player 1;\nPlease try again; or type -1 to exit.\n\n";
                                cin >> loginName;
				                user = findUser(list, loginName);
                            }
                            else
                            {
                                //If user not found, re prompt user
				                cout << "\nUsername not found. Please try again; or type -1 to exit.\n\n";
				                cin >> loginName;
				                user = findUser(list, loginName);
                            }
			            }

                        // if user entered -1 for user name then play as guest
			            if(loginName.compare("-1") == 0)
			            {
				            cout << "\nYou will now be logged in as a guest.\n";
				            player2User = &guest1;

                            // set guest flag to true
                            playasGuest = true;

                            // leave outer loop
                            break;
			            }

                        // initial prompt for password
                        cout << "\nPlease enter your password\n\n";
			            cin >> password;

                        // loop until correct password is entered or until user enters '-1'
                        while(password.compare(user->password) != 0 && password.compare("-1") != 0)
			            {
				            //If wrong password, reprompt user
				            cout << "\nInccorect passward. Please try again; or type -1 to try a new username.\n\n";
				            cin >> password;
                            cin.ignore();
			            }

                        // if user enters a correct password then login is complete. exit outer loop
                        if (password.compare(user->password) == 0)
                            break;

                        // else loop to beginning to enter a new username

                    }// END OF OUTER LOOP

                    // if guest flag is true then break out of switch statement to start game as guest
                    if (playasGuest)
                        break;

					player2User = user;
					//New line
					cout << " \n";

					//Display user information
					display(*user);

					system("pause");
					break;
				}
			case 2:
				{
					//Variable for new username
					string newUser;
					UserInfo* user = new UserInfo;

					//Prompt
					cout << "\nEnter your new username or press -1 to cancel:\n";
					cin >> newUser;

					//Ignore blank line
					cin.ignore();

                    //Check for username existing in file already
			        UserInfo* test = findUser(list, newUser);
                
                    // loop until a user name is found or if user enters '-1'
                    while(test != 0 && newUser.compare("-1") != 0)
			        {
				        //If user not found, re prompt user
				        cout << "\nUsername already in use. Please try again; or type -1 to exit.\n\n";
				        cin >> newUser;
				        test = findUser(list, loginName);
			        }
			
					//Input username
					if (newUser.compare("-1") == 0)
					{
						cout << "\nYou will now be logged in as a guest.\n";
						//-1 means cancel
						player2User = &guest2;
						break;
					}
					user->name = newUser;

					//Input password
					cout << "\nEnter you desired password.\n";
					cin >> user -> password;

					//Ignore blank line
					cin.ignore();

					//Input e-mail
					cout << "\nEnter you e-mail (including @).\n";
					cin >> user -> email;

					//Ignore blank line
					cin.ignore();

					///Setting the wins, draws, and lossed to 0
					user -> wins = user -> losses = user -> draws = 0;

					//New line
					cout << " \n";

					//Display user information
					display(*user);

					system("pause");

					//adding new user to the main list
					list.push_back(*user);

                    //assigning our new user to player 2
                    player2User = &list.back();
				}
				break;
			case 3: 
				player2User = &guest2;	//Assigns guest to player 2
				break;
			}
			
				 //Display Title                                  
				for (int i = 0; i < 3; i++)
				{
					cout << title[i];	
				}

				cout << " \n" << endl;

				//Display question for BOARD_SIZE
				cout << "\nPlease chose a board size.\n";
				cout << "-----------------------------\n\n";
				cout << "3. 3 x 3 board\n";
				cout << "4. 4 x 4 board\n";
				cout << "5. 5 x 5 board\n";
				cin >> userChoiceSize;  //Get user's size choice

				while (userChoiceSize < 3 || userChoiceSize > 5)
				{                     
					for (int i = 0; i < 3; i++)
					{
						cout << title[i];	
					}

					cout << " \n" << endl;

					//Error trap to check for 3, 4, or 5 to be entered.
					cout << "\n\nYou did not enter 3, 4, or 5. Please chose a valid option.\n\n";
					cin >> userChoiceSize;

					cout << "\nPlease chose a board size.\n";
					cout << "-----------------------------\n\n";
					cout << "3. 3 x 3 board\n";
					cout << "4. 4 x 4 board\n";
					cout << "5. 5 x 5 board\n";
					cin >> userChoiceSize;  //Get user's size choice
				}

				//Set the modifier for board size
				if (userChoiceSize == 3)
					modifier = 7;
				else if (userChoiceSize == 4)
					modifier = 13;
				else
					modifier = 21;

				//Set Board Size to choice
				BOARD_SIZE = userChoiceSize;

			//start new game against another player
			newGame(false);	
		}
		else
		{
			cout << "\nRetuning to login menu...\n\n";
			break; //If user enters option 3; return to login.
		}

		do
		{
			//Display the board
			display();
			//Get input from users
			input();
			//Update board display
			update();
		}// loop unit winner or draw game
		while(!winner() && !other());

		end();
		}
		system("pause");

        // get number of accounts
		numOfAccounts = list.size();

        // open file
		fstream file( "users.txt", ios::out );

        // write all accounts to file
		file << numOfAccounts << endl;
		for (int count = 0; count < numOfAccounts; count++)
			writeUsersToFile( list[count], file );

        // close file
        file.close();

	}// END OF MAIN LOOP

} // END OF PROGRAM

//Make sure input is a number
int checkNum (string prompt)
{
	int value;
	int limit = BOARD_SIZE * BOARD_SIZE;  // Set limit variable to allow numbers for larger boards

	cout << prompt;

	//Make sure value is 0 - 9 for number pad entry
	while(!(cin >> value) || value < 1 || value > limit)
	{
		if (!cin)  //Value is not a number
		{
			cin.clear();  //Clear the error
			cin.ignore(10000, '\n');  //Double Check up to 10,000
		}

		cout << "\nInvalid input!\n";
		cout << prompt;
	}

	cin.ignore();

	return value;
}




void newGame(bool com)
{
	//Initialize board, 
	board = new char*[BOARD_SIZE];

	//Specify size from user
	for (int i = 0; i  < BOARD_SIZE; i++)
	{
		board[i] = new char[BOARD_SIZE];
	}

	//Make board
	for (int row = 0; row < BOARD_SIZE; row++)  //Rows
	{
		for (int col= 0; col < BOARD_SIZE; col++)  //Columns
		{
			board[row][col] = ' ';
		}
	}

	//Initialize all game setup
	player1 = false;		//Which player
	invalidMove = false;	//Accepted move
	moveCount = 0;			//Count up until 9 is reached
	win = false;			//Winner?
	draw = false;			//Draw?

	//For CPU foe
	cpu = com;
}





void swapTurn()
{
	//Check for player
	player1 = player1?false : true;
}





void display()
{
	system("cls");

	//Change between players
	if (!win && !draw && !invalidMove)
		swapTurn();

	/*
	 *  Displays Board and Key Map:
	 *
	 *     |   |            7 | 8 | 9
	 *  ---+---+---        ---+---+---
	 *     |   |            4 | 5 | 6
	 *  ---+---+---        ---+---+---
	 *     |   |            1 | 2 | 3
	 */

	  //Display Title
	string title[3] = {"+-+-+-+-+-+-+-+-+-+-+-+\n",
					   "|T|i|c|-|T|a|c|-|T|o|e|\n",
					   "+-+-+-+-+-+-+-+-+-+-+-+\n"};
                                                   
	for (int i = 0; i < 3; i++)
	{
		cout << title[i];	
	}

	cout << " \n" << endl;
                                                                                     
	//Board

	for (int row = 0; row < BOARD_SIZE; row++)  //Display rows
	{	cout << "   ";

		for (int column = 0; column < BOARD_SIZE; column++)   //Display columns
		{
            cout << " " << board[row][column] << " ";  //Display Board Character: X/O
			
            if (column < BOARD_SIZE - 1)
				cout << "|";  //Borders
		}
		cout << "     ";

		for (int column = 0; column < BOARD_SIZE; column++)  //Create Number Pad
		{
			cout << " " << (modifier - row * BOARD_SIZE + column);  //Display the key number
			
			if ((modifier - row * BOARD_SIZE + column) < 10) //Adds a space for numbers < 10
				cout << " ";

			if (column < BOARD_SIZE - 1)
				cout << "|";  //Borders
		}
		cout << endl;

		if (row < BOARD_SIZE - 1)  //Horizontal lines through the board
		{
			cout << "   ---";

			for (int i = 0; i < BOARD_SIZE - 1; i++)  
			{
				cout << "+---";
			}

			cout << "     ---";

			for (int i = 0; i < BOARD_SIZE - 1; i++)
			{
				cout << "+---";
			}
		}

		cout << endl;
	}

	if (invalidMove)
	{
		cout << " " << endl;
		cout << "Invalid Move! You cannot place a mark \nwhere one is already placed.\n" << endl;
	}
}





void update()
{
	invalidMove = false;

	/*
	 * Number Pad EXAMPLE (3 x 3)
	 *
	 *  [coordinates]     [space numbers]
	 *
	 *   0 0|0 1|0 2        7 | 8 | 9
	 *   ---+---+---       ---+---+---
	 *   1 0|1 1|1 2        4 | 5 | 6
	 *   ---+---+---       ---+---+---
	 *   2 0|2 1|2 2        1 | 2 | 3
	 */
	
	// 'count' will represent a spot on the board
	int count = 1;
	for (int row = 0; row < BOARD_SIZE; row++) 
	{	
		for (int column = 0; column < BOARD_SIZE; column++)  
		{
			if (user_input == count)  
			{	
				// if chosen spot is empty
				if (board[(BOARD_SIZE - 1) - row][column] == ' ')  
				{	
					//mark board with an X or O depending on whose turn. Increment the move count and then exit function
					board[(BOARD_SIZE - 1) - row][column] = (player1? 'X' : 'O');

					moveCount++;
					return;
				}

				  // else space is taken. Set flag and exit function
				else  
                {
					invalidMove = true;
					return;
				}

			}
			count++;
		}
	}
	//if spot on board is never found then user entered a number out of range
	invalidMove = true;
}




void input()
{
	//create stringstream object
	stringstream prompt;

    prompt << endl << (player1? player1User -> name : player2User -> name) << " turn:";  //Display player 1 or player 2 name
	cout << "Please enter the cooresponding number from the \nNumber Key Pad on the right to place your mark.\n\n";

	//COMPUTER
	if (!player1 && cpu)
	{
		user_input = computerMove();
	}

	//OTHER PLAYER
	else
		user_input = checkNum(prompt.str());
}





bool winner()
{
	/*
    *  [coordinates]
    *
    *   0 0|0 1|0 2
    *   ---+---+---
    *   1 0|1 1|1 2
    *   ---+---+---
    *   2 0|2 1|2 2
    */
	int row, column;

	// Horizontal Check 
	for (row = 0; row < BOARD_SIZE; row++)  
	{	
		column = 0;
		while (column < BOARD_SIZE && board[row][column] == (player1? 'X' : 'O'))
		{
			column++;
		}

		// if three straight markings
		if (column >= BOARD_SIZE) 
		{	
			win = true;
			return true;
		}
	}
	//Vertical Check
	for (column = 0; column < BOARD_SIZE; column++)  
	{	
		row = 0;
		while (row < BOARD_SIZE && board[row][column] == (player1? 'X' : 'O'))
			row++;

		// if three straight markings
		if (row >= BOARD_SIZE)  
		{	
			win = true;
			return true;
		}
	}	

	//TOP-LEFT to BOTTOM-RIGHT Diagonal Check
	
	//Inititate counter
	column = 0;

	//Loop, to check diagonal upper left to lower right
	while (column < BOARD_SIZE && board[column][column] == (player1? 'X' : 'O'))  
	{
		column++;
	} //Return to loop a second time to check lower left to upper right

	// if three straight markings
	if (column >= BOARD_SIZE) 
	{	
		win = true;
		return true;
	}

	//BOTTOM-LEFT to TOP-RIGHT Diagonal Check
	
	//Inititate counters
	column = 0;
	row = 0;

	//Loop, to check diagonal upper left to lower right
	while (column < BOARD_SIZE && board[BOARD_SIZE - 1 - row][column] == (player1? 'X' : 'O'))  
	{
		column++;
		row++;
	} //Loop until it finds an opponent's character

	// if specified consecutive straight markings
	if (column >= BOARD_SIZE) 
	{	
		win = true;
		return true;
	}

	//if all checks fail
	return false;
}





//If a tie
bool other ()
{
	if (!win && moveCount == BOARD_SIZE * BOARD_SIZE)  //no winner and max number of moves in tic tac toe)
		draw = true;

	return draw;
}






void end()
{
	display();

    // if there is a winner
	if (win)
	{
		cout << "\n" << (player1? player1User -> name : player2User -> name)  << " wins! :D \n\n";
		cout << "You will now be redirected to the main menu.\n\n\n";
        
        // update stats based on winner
        if (player1)
        {
            player1User->wins++;
            player2User->losses++;
        }
        else
        {
            player2User->wins++;
            player1User->losses++;
        }
	}
	else // a draw
	{
		cout << "\nGame is a draw :( . \n";
		cout << "You will now be redirected to the main menu.\n\n\n";
		player1User->draws++;
		player2User->draws++;
	}
}




int computerMove()
{
	//From ctime, initialize to 0
	srand((unsigned) time(0));

	//Create new array to store computer moves
	int *compArray = new int[BOARD_SIZE * BOARD_SIZE];
	int compArrayIndex = 0;

	for (int row = 0; row < BOARD_SIZE; row++)  //Rows
	{
	
		for (int col= 0; col < BOARD_SIZE; col++)  //Columns
		{
			if (board[row][col] == ' ')
			{
				compArray[compArrayIndex++] = (modifier - row * BOARD_SIZE + col);  //at row 0 col 0, the value input is 7; etc.
			}
		}
	}

	//Computer move randomized
	return compArray[rand() % compArrayIndex];
}

/*
************************
*USER ACCOUNT FUNCTIONS*
************************
*/

//Reads one user from the file
void readUsersFromFile( UserInfo& user, fstream& file )
{
    getline( file, user.name );         //Full name including spaces
    getline( file, user.password );     //Password
    getline( file, user.email );        //email including @
    file >> user.wins >> user.losses >> user.draws;     //Gets the game stats and records
    file.ignore();
}





//Writes one user to file (Creates an account)
void writeUsersToFile( UserInfo& user, fstream& file )
{
    file << user.name << endl;
    file << user.password << endl;
    file << user.email << endl;
    file << user.wins << endl;
    file << user.losses << endl;
    file << user.draws << endl;
}





//Finds the specified username from userList to log in
UserInfo* findUser( UserList& list, string name )
{
    //If username is found, function is returned; will return a user as a full object
    for (int i = 0; i < list.size(); i++)
    {
        if ( list[i].name.compare( name ) == 0)
        {
            return &list[i];
        }
    }

    //Else it will return zero (leading to "account doesn't exist" message)
    return 0;
}




//Displays user info
void display( const UserInfo& user )
{
    cout << "Name: " << user.name << endl;
    cout << "Password: " << user.password << endl;
    cout << "E-mail: " << user.email << endl;
    cout << "Wins: " << user.wins << endl;
    cout << "Losses: " << user.losses << endl;
    cout << "Draws: " << user.draws << endl;
}